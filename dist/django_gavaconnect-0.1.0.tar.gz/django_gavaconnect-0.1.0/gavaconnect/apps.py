from django.apps import AppConfig

class GavaconnectConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gavaconnect"
    verbose_name = "GavaConnect (KRA) Client"
